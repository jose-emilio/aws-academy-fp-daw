const awsConfig = {
    // Cambia esto a tu región, sólo puede ser us-east-1 o us-west-2, las regiones permitidas en los AWS Academy Learner Labs
    region: 'us-east-1',
    // Sustituye por tu Access Key ID del AWS Academy Learner Lab
    accessKeyId: 'ID-Clave-Acceso',
    // Sustituye por tu Secret Access Key del AWS Academy Learner Lab
    secretAccessKey: 'Clave-Acceso-Secreta',
    // Sustituye por tu Session Token del AWS Academy Learner Lab
    sessionToken: 'Token-Sesion',
    // Sustituye por tu URL de la cola de SQS creada
    queueUrl: 'URL-cola' 
};

AWS.config.update({
    region: awsConfig.region,
    accessKeyId: awsConfig.accessKeyId,
    secretAccessKey: awsConfig.secretAccessKey,
    sessionToken: awsConfig.sessionToken
});
