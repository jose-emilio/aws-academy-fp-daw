document.getElementById('messageForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const messageBody = document.getElementById('messageBody').value;
    const attributesContainer = document.getElementById('attributesContainer');
    const attributeElements = attributesContainer.getElementsByClassName('attribute');
    
    let messageAttributes = {};

    for (let attributeElement of attributeElements) {
        const key = attributeElement.getElementsByClassName('key')[0].value;
        const value = attributeElement.getElementsByClassName('value')[0].value;

        if (key && value) {
            messageAttributes[key] = {
                DataType: 'String',
                StringValue: value
            };
        }
    }

    const params = {
        MessageBody: messageBody,
        QueueUrl: awsConfig.queueUrl,
        MessageAttributes: messageAttributes
    };

    sqs = new AWS.SQS();

    sqs.sendMessage(params, function(err, data) {
        if (err) {
            console.error("Error", err);
        } else {
            console.log("Success", data.MessageId);
            alert('Mensaje enviado con éxito!');
        }
    });
});

document.getElementById('addAttribute').addEventListener('click', function() {
    const attributesContainer = document.getElementById('attributesContainer');
    const attributeDiv = document.createElement('div');
    attributeDiv.className = 'attribute';

    attributeDiv.innerHTML = `
        <input type="text" class="key" placeholder="Clave">
        <input type="text" class="value" placeholder="Valor">
        <button type="button" class="removeAttribute">Eliminar</button>
    `;

    attributesContainer.appendChild(attributeDiv);

    const removeButtons = attributesContainer.getElementsByClassName('removeAttribute');
    for (let button of removeButtons) {
        button.addEventListener('click', function() {
            this.parentElement.remove();
        });
    }
});